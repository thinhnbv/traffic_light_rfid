`timescale 1ns/1ps
module tb_peripherals;
    reg clk=0;
    reg rst_async_n;
    wire rst_sync_n;

    reg cdc_d;
    wire cdc_q;

    reg rs_tx_start,rs_tx_done;
    wire rs485_de,tx_enable;

    reg spi_start;
    reg [7:0] spi_tx_data;
    reg spi_miso;
    wire spi_sck,spi_mosi;
    wire [7:0] spi_rx_data;
    wire spi_done;

    integer pass_count=0,fail_count=0,k,rises;
    reg sck_prev;

    rst_sync u_rst(.clk(clk),.rst_async_n(rst_async_n),.rst_sync_n(rst_sync_n));
    cdc_sync #(.W(1)) u_cdc(.clk_dst(clk),.rst_n(rst_sync_n),.d(cdc_d),.q(cdc_q));
    rs485_dir_ctrl #(.GUARD_CYCLES(14'd6)) u_rs(
        .clk(clk),.rst_n(rst_sync_n),.tx_start(rs_tx_start),.tx_done(rs_tx_done),
        .rs485_de(rs485_de),.tx_enable(tx_enable)
    );
    spi_master u_spi(
        .clk(clk),.rst_n(rst_sync_n),.start(spi_start),.tx_data(spi_tx_data),
        .clk_div(3'd1),.spi_miso(spi_miso),.spi_sck(spi_sck),
        .spi_mosi(spi_mosi),.rx_data(spi_rx_data),.done(spi_done)
    );

    always #10 clk=~clk;
    task check; input cond; input [8*110-1:0] msg;
      begin if(cond) begin pass_count=pass_count+1;$display("[PASS] %0s",msg);end
      else begin fail_count=fail_count+1;$display("[FAIL] %0s",msg);end end
    endtask

    initial begin
        rst_async_n=0;cdc_d=0;rs_tx_start=0;rs_tx_done=0;spi_start=0;spi_tx_data=0;spi_miso=0;
        #7; check(rst_sync_n===1'b0,"Reset asserts asynchronously");
        rst_async_n=1;
        @(posedge clk);#1;check(rst_sync_n==0,"Reset remains asserted after first clock");
        @(posedge clk);#1;check(rst_sync_n==1,"Reset releases synchronously after two stages");

        cdc_d=1;
        @(posedge clk);@(posedge clk);#1;
        check(cdc_q==1,"CDC synchronizer transfers input after two clocks");

        rs_tx_start=1;@(posedge clk);rs_tx_start=0;#1;
        check(rs485_de==1,"RS485 DE asserts on TX request");
        @(posedge clk);#1;check(tx_enable==1,"RS485 tx_enable active after DE assertion");
        rs_tx_done=1;@(posedge clk);rs_tx_done=0;#1;
        check(rs485_de==1 && tx_enable==0,"RS485 guard begins after TX done");
        repeat(8) @(posedge clk);#1;
        check(rs485_de==0,"RS485 DE returns low after guard delay");

        spi_tx_data=8'hA5; spi_miso=1'b1; spi_start=1;
        @(posedge clk);spi_start=0;
        rises=0;sck_prev=spi_sck;
        begin : WAIT_SPI
            for(k=0;k<200;k=k+1) begin
                @(posedge clk);#1;
                if(!sck_prev && spi_sck) rises=rises+1;
                sck_prev=spi_sck;
                if(spi_done) disable WAIT_SPI;
            end
        end
        check(spi_done,"SPI transaction completes");
        check(rises==8,"SPI generates eight rising SCK edges");
        check(spi_rx_data==8'hFF,"SPI samples MISO high into 0xFF");

        $display("PERIPHERALS SUMMARY PASS=%0d FAIL=%0d",pass_count,fail_count);
        if(fail_count==0)$display("OVERALL RESULT: PASS"); else $display("OVERALL RESULT: FAIL");
        $finish;
    end
endmodule
