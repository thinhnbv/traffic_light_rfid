transcript on
set SCRIPT_DIR [file normalize [file dirname [info script]]]
set SRC_DIR [file normalize [file join $SCRIPT_DIR .. src]]
set WORK_DIR [file normalize [file join $SCRIPT_DIR work_full_verify]]

if {![file exists $WORK_DIR]} { vlib $WORK_DIR }
vmap work $WORK_DIR

set RTL [list \
 [file join $SRC_DIR uart_tx_core.v] \
 [file join $SRC_DIR uart_rx_core.v] \
 [file join $SRC_DIR cascade_tx.v] \
 [file join $SRC_DIR cascade_rx.v] \
 [file join $SRC_DIR cascade_ctrl.v] \
 [file join $SRC_DIR rs485_dir_ctrl.v] \
 [file join $SRC_DIR rst_sync.v] \
 [file join $SRC_DIR cdc_sync.v] \
 [file join $SRC_DIR spi_master.v] \
 [file join $SRC_DIR rc522_driver_x4.v] \
 [file join $SRC_DIR seg7_countdown.v] \
]

foreach f $RTL {
 if {![file exists $f]} {
   puts "ERROR: Missing RTL file $f"
   return
 }
}

proc run_tb {name rtl tbfile} {
    puts "\n================ RUNNING $name ================"
    eval vlog +define+SIMULATION $rtl $tbfile
    vsim -c work.$name -do "run -all; quit -sim"
}

run_tb tb_uart_loopback [list [lindex $RTL 0] [lindex $RTL 1]] [file join $SCRIPT_DIR tb_uart_loopback.v]
run_tb tb_cascade_packet_loopback [list [lindex $RTL 0] [lindex $RTL 1] [lindex $RTL 2] [lindex $RTL 3]] [file join $SCRIPT_DIR tb_cascade_packet_loopback.v]
run_tb tb_cascade_ctrl [list [lindex $RTL 4]] [file join $SCRIPT_DIR tb_cascade_ctrl.v]
run_tb tb_greenwave_link [list [lindex $RTL 0] [lindex $RTL 1] [lindex $RTL 2] [lindex $RTL 3] [lindex $RTL 4]] [file join $SCRIPT_DIR tb_greenwave_link.v]
run_tb tb_peripherals [list [lindex $RTL 5] [lindex $RTL 6] [lindex $RTL 7] [lindex $RTL 8]] [file join $SCRIPT_DIR tb_peripherals.v]
run_tb tb_rc522_smoke [list [lindex $RTL 8] [lindex $RTL 9]] [file join $SCRIPT_DIR tb_rc522_smoke.v]
run_tb tb_seg7_countdown [list [lindex $RTL 10]] [file join $SCRIPT_DIR tb_seg7_countdown.v]

puts "\nAll full-system verification testbenches completed."
