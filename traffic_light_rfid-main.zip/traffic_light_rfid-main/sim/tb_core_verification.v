`timescale 1ns/1ps
`define SIMULATION

// =============================================================================
// Self-checking functional verification testbench
// Scope: RFID UID stimulus -> LUT -> priority arbiter -> direction detector
//        -> traffic FSM -> traffic-light outputs
// Green-wave/UART/RS485 are intentionally excluded.
// =============================================================================
module tb_core_verification;

    localparam CLK_PERIOD = 20; // 50 MHz

    // FSM state encodings
    localparam [3:0] S_NS_GREEN   = 4'd0;
    localparam [3:0] S_NS_YELLOW  = 4'd1;
    localparam [3:0] S_ALL_RED_1  = 4'd2;
    localparam [3:0] S_EW_GREEN   = 4'd3;
    localparam [3:0] S_EW_YELLOW  = 4'd4;
    localparam [3:0] S_ALL_RED_2  = 4'd5;
    localparam [3:0] S_PRIO_CLEAR = 4'd6;
    localparam [3:0] S_PRIO_HOLD  = 4'd7;
    localparam [3:0] S_PRIO_EXIT  = 4'd8;
    localparam [3:0] S_PRIO_RECOV = 4'd9;

    // Registered UIDs used by tag_priority_lut.v
    localparam [31:0] UID_TIER5 = 32'h69C3D106;
    localparam [31:0] UID_TIER4 = 32'h9E48CE06;
    localparam [31:0] UID_TIER3 = 32'h1E2CD006;
    localparam [31:0] UID_TIER2 = 32'h21F44D06;
    localparam [31:0] UID_TIER1 = 32'h92D94D06;
    localparam [31:0] UID_NORMAL = 32'hDEADBEEF;

    reg clk;
    reg rst_n;

    reg [3:0]  sim_tag_detected;
    reg [31:0] sim_uid_n;
    reg [31:0] sim_uid_s;
    reg [31:0] sim_uid_e;
    reg [31:0] sim_uid_w;

    wire [2:0] class_n, class_s, class_e, class_w;
    wire       arb_ev_ns, arb_ev_ew;
    wire [2:0] arb_winner;

    wire [1:0] dir_out;
    wire       dir_valid;
    wire       dir_confidence;
    wire       any_detected;

    wire ns_r, ns_y, ns_g;
    wire ew_r, ew_y, ew_g;
    wire prio_active;
    wire [3:0] cur_state;
    wire timer_load;
    wire [31:0] timer_value;

    integer pass_count;
    integer fail_count;
    integer scenario_id;

    assign any_detected = |sim_tag_detected;

    // -------------------------------------------------------------------------
    // DUT chain
    // -------------------------------------------------------------------------
    tag_priority_lut u_lut_n (.uid(sim_uid_n), .priority_class(class_n));
    tag_priority_lut u_lut_s (.uid(sim_uid_s), .priority_class(class_s));
    tag_priority_lut u_lut_e (.uid(sim_uid_e), .priority_class(class_e));
    tag_priority_lut u_lut_w (.uid(sim_uid_w), .priority_class(class_w));

    priority_arbiter u_arb (
        .tag_detected (sim_tag_detected),
        .class_n      (class_n),
        .class_s      (class_s),
        .class_e      (class_e),
        .class_w      (class_w),
        .cur_state    (cur_state),
        .ev_detect_ns (arb_ev_ns),
        .ev_detect_ew (arb_ev_ew),
        .winner_class (arb_winner)
    );

    direction_detector #(
        .CNT_DIR_TIMEOUT(32'd20)
    ) u_dir (
        .clk            (clk),
        .rst_n          (rst_n),
        .tag_detected   (sim_tag_detected),
        .any_detected   (any_detected),
        .dir_out        (dir_out),
        .dir_valid      (dir_valid),
        .dir_confidence (dir_confidence)
    );

    traffic_fsm #(
        .CNT_GREEN_NS(32'd12),
        .CNT_GREEN_EW(32'd10),
        .CNT_YELLOW  (32'd5),
        .CNT_ALL_RED (32'd3),
        .CNT_PRIO_CLR(32'd5),
        .CNT_PRIO_TMO(32'd14)
    ) u_fsm (
        .clk              (clk),
        .rst_n            (rst_n),
        .ev_detect_ns     (arb_ev_ns),
        .ev_detect_ew     (arb_ev_ew),
        .prio_class       (arb_winner),
        .cascade_preclear (1'b0),
        .ns_r             (ns_r),
        .ns_y             (ns_y),
        .ns_g             (ns_g),
        .ew_r             (ew_r),
        .ew_y             (ew_y),
        .ew_g             (ew_g),
        .prio_active      (prio_active),
        .cur_state        (cur_state),
        .timer_load       (timer_load),
        .timer_value      (timer_value)
    );

    // -------------------------------------------------------------------------
    // Clock
    // -------------------------------------------------------------------------
    initial begin
        clk = 1'b0;
        forever #(CLK_PERIOD/2) clk = ~clk;
    end

    // -------------------------------------------------------------------------
    // Utility tasks
    // -------------------------------------------------------------------------
    task clear_inputs;
    begin
        sim_tag_detected = 4'b0000;
        sim_uid_n = 32'd0;
        sim_uid_s = 32'd0;
        sim_uid_e = 32'd0;
        sim_uid_w = 32'd0;
    end
    endtask

    task reset_dut;
    begin
        clear_inputs();
        rst_n = 1'b0;
        repeat (4) @(posedge clk);
        rst_n = 1'b1;
        repeat (4) @(posedge clk);
    end
    endtask

    task check;
        input condition;
        input [8*120-1:0] message;
    begin
        if (condition) begin
            pass_count = pass_count + 1;
            $display("[PASS][%0t] %0s", $time, message);
        end else begin
            fail_count = fail_count + 1;
            $display("[FAIL][%0t] %0s", $time, message);
        end
    end
    endtask

    task wait_state;
        input [3:0] expected_state;
        input integer max_cycles;
        integer k;
        reg found;
    begin
        found = 1'b0;
        begin : WAIT_LOOP
            for (k = 0; k < max_cycles; k = k + 1) begin
                @(posedge clk);
                #1;
                if (cur_state == expected_state) begin
                    found = 1'b1;
                    disable WAIT_LOOP;
                end
            end
        end
        check(found, "FSM reached expected state");
    end
    endtask

    task expect_lights;
        input exp_ns_r, exp_ns_y, exp_ns_g;
        input exp_ew_r, exp_ew_y, exp_ew_g;
    begin
        #1;
        check({ns_r,ns_y,ns_g,ew_r,ew_y,ew_g} ==
              {exp_ns_r,exp_ns_y,exp_ns_g,exp_ew_r,exp_ew_y,exp_ew_g},
              "Traffic-light Moore outputs are correct");
    end
    endtask

    task pulse_sequence_east;
    begin
        // S -> S+E -> E -> none; expected exit EAST
        sim_uid_s = UID_TIER3;
        sim_uid_e = UID_TIER3;
        sim_tag_detected = 4'b0100;
        repeat (3) @(posedge clk);
        sim_tag_detected = 4'b0110;
        repeat (3) @(posedge clk);
        sim_tag_detected = 4'b0010;
        repeat (3) @(posedge clk);
        sim_tag_detected = 4'b0000;
    end
    endtask

    // -------------------------------------------------------------------------
    // Safety assertions checked continuously
    // -------------------------------------------------------------------------
    always @(posedge clk) begin
        if (rst_n) begin
            if (ns_g && ew_g) begin
                fail_count = fail_count + 1;
                $display("[FAIL][%0t] SAFETY: NS and EW green simultaneously", $time);
            end
            if ((ns_g || ns_y) && !ew_r) begin
                fail_count = fail_count + 1;
                $display("[FAIL][%0t] SAFETY: EW red must be ON while NS moves", $time);
            end
            if ((ew_g || ew_y) && !ns_r) begin
                fail_count = fail_count + 1;
                $display("[FAIL][%0t] SAFETY: NS red must be ON while EW moves", $time);
            end
        end
    end

    // -------------------------------------------------------------------------
    // Test sequence
    // -------------------------------------------------------------------------
    initial begin
        pass_count = 0;
        fail_count = 0;
        scenario_id = 0;
        rst_n = 1'b0;
        clear_inputs();

        // Optional VCD for GTKWave
        $dumpfile("tb_core_verification.vcd");
        $dumpvars(0, tb_core_verification);

        // =====================================================================
        // TC1: Reset initialization
        // =====================================================================
        scenario_id = 1;
        $display("\n=== TC1 RESET INITIALIZATION ===");
        reset_dut();
        check(cur_state == S_NS_GREEN, "Reset state is S_NS_GREEN");
        expect_lights(0,0,1, 1,0,0);
        check(prio_active == 1'b0, "Priority mode is inactive after reset");

        // =====================================================================
        // TC2: Normal traffic cycle
        // =====================================================================
        scenario_id = 2;
        $display("\n=== TC2 NORMAL TRAFFIC CYCLE ===");
        wait_state(S_NS_YELLOW, 30);
        expect_lights(0,1,0, 1,0,0);
        wait_state(S_ALL_RED_1, 15);
        expect_lights(1,0,0, 1,0,0);
        wait_state(S_EW_GREEN, 15);
        expect_lights(1,0,0, 0,0,1);
        wait_state(S_EW_YELLOW, 25);
        expect_lights(1,0,0, 0,1,0);
        wait_state(S_ALL_RED_2, 15);
        expect_lights(1,0,0, 1,0,0);
        wait_state(S_NS_GREEN, 15);

        // =====================================================================
        // TC3: Opposite-axis priority preemption
        // Start from EW_GREEN, assert NS Tier-5 vehicle.
        // Expected: EW_GREEN -> EW_YELLOW -> ALL_RED_2 -> PRIO_CLEAR -> HOLD(NS)
        // =====================================================================
        scenario_id = 3;
        $display("\n=== TC3 NS PRIORITY DURING EW GREEN ===");
        wait_state(S_EW_GREEN, 60);
        sim_uid_n = UID_TIER5;
        sim_tag_detected = 4'b1000;
        repeat (2) @(posedge clk);
        check(arb_ev_ns && !arb_ev_ew && arb_winner == 3'd5,
              "Arbiter grants Tier-5 NS vehicle");
        wait_state(S_EW_YELLOW, 10);
        wait_state(S_ALL_RED_2, 15);
        wait_state(S_PRIO_CLEAR, 15);
        expect_lights(1,0,0, 1,0,0);
        wait_state(S_PRIO_HOLD, 20);
        expect_lights(0,0,1, 1,0,0);
        check(prio_active, "Priority active is asserted in PRIO_HOLD");

        // =====================================================================
        // TC4: Tag loss, priority exit, recovery
        // =====================================================================
        scenario_id = 4;
        $display("\n=== TC4 TAG LOSS AND RECOVERY ===");
        sim_tag_detected = 4'b0000;
        sim_uid_n = 32'd0;
        wait_state(S_PRIO_EXIT, 8);
        expect_lights(0,1,0, 1,0,0);
        wait_state(S_PRIO_RECOV, 15);
        expect_lights(1,0,0, 1,0,0);
        wait_state(S_NS_GREEN, 15);
        check(!prio_active, "Priority mode returns inactive after recovery");

        // =====================================================================
        // TC5: Priority HOLD timeout fail-safe
        // Keep NS event asserted until timeout.
        // =====================================================================
        scenario_id = 5;
        $display("\n=== TC5 PRIORITY TIMEOUT FAIL-SAFE ===");
        sim_uid_n = UID_TIER3;
        sim_tag_detected = 4'b1000;
        wait_state(S_PRIO_CLEAR, 10);
        wait_state(S_PRIO_HOLD, 20);
        wait_state(S_PRIO_EXIT, 30);
        check(cur_state == S_PRIO_EXIT,
              "FSM exits PRIO_HOLD when priority timeout expires");
        sim_tag_detected = 4'b0000;
        sim_uid_n = 32'd0;
        wait_state(S_PRIO_RECOV, 15);
        wait_state(S_NS_GREEN, 15);

        // =====================================================================
        // TC6: Direction detection, normal confidence
        // =====================================================================
        scenario_id = 6;
        $display("\n=== TC6 DIRECTION DETECTION: EAST ===");
        pulse_sequence_east();
        begin : WAIT_DIR_VALID_1
            integer n;
            reg seen_valid;
            seen_valid = 1'b0;
            for (n = 0; n < 10; n = n + 1) begin
                @(posedge clk);
                #1;
                if (dir_valid) begin
                    seen_valid = 1'b1;
                    check(dir_out == 2'b10, "Direction output is EAST");
                    check(dir_confidence == 1'b1,
                          "Direction confidence is HIGH for multi-reader sequence");
                    disable WAIT_DIR_VALID_1;
                end
            end
            if (!seen_valid)
                check(1'b0, "Direction detector produced dir_valid pulse");
        end
        clear_inputs();
        repeat (4) @(posedge clk);

        // =====================================================================
        // TC7: Direction low-confidence single-reader case
        // =====================================================================
        scenario_id = 7;
        $display("\n=== TC7 DIRECTION LOW CONFIDENCE ===");
        sim_uid_w = UID_NORMAL;
        sim_tag_detected = 4'b0001;
        repeat (4) @(posedge clk);
        sim_tag_detected = 4'b0000;
        begin : WAIT_DIR_VALID_2
            integer n;
            reg seen_valid;
            seen_valid = 1'b0;
            for (n = 0; n < 10; n = n + 1) begin
                @(posedge clk);
                #1;
                if (dir_valid) begin
                    seen_valid = 1'b1;
                    check(dir_out == 2'b11, "Single-reader direction resolves WEST");
                    check(dir_confidence == 1'b0,
                          "Single-reader sequence is marked LOW confidence");
                    disable WAIT_DIR_VALID_2;
                end
            end
            if (!seen_valid)
                check(1'b0, "Low-confidence direction produced dir_valid pulse");
        end
        clear_inputs();
        repeat (4) @(posedge clk);

        // =====================================================================
        // TC8: Priority arbitration and tie-break
        // =====================================================================
        scenario_id = 8;
        $display("\n=== TC8 PRIORITY ARBITRATION ===");
        // NS class 5 versus EW class 3 => NS wins.
        sim_uid_n = UID_TIER5;
        sim_uid_e = UID_TIER3;
        sim_tag_detected = 4'b1010;
        #1;
        check(arb_ev_ns && !arb_ev_ew && arb_winner == 3'd5,
              "Higher NS class wins arbitration");

        // NS class 3 versus EW class 5 => EW wins.
        sim_uid_n = UID_TIER3;
        sim_uid_e = UID_TIER5;
        #1;
        check(!arb_ev_ns && arb_ev_ew && arb_winner == 3'd5,
              "Higher EW class wins arbitration");

        // Equal class while NS_GREEN => NS wins.
        clear_inputs();
        repeat (2) @(posedge clk);
        reset_dut();
        sim_uid_n = UID_TIER4;
        sim_uid_e = UID_TIER4;
        sim_tag_detected = 4'b1010;
        #1;
        check(cur_state == S_NS_GREEN && arb_ev_ns && !arb_ev_ew,
              "Equal-class tie keeps current NS green axis");

        // Equal class while EW_GREEN => EW wins.
        clear_inputs();
        wait_state(S_EW_GREEN, 60);
        sim_uid_n = UID_TIER4;
        sim_uid_e = UID_TIER4;
        sim_tag_detected = 4'b1010;
        #1;
        check(cur_state == S_EW_GREEN && !arb_ev_ns && arb_ev_ew,
              "Equal-class tie keeps current EW green axis");
        clear_inputs();

        // =====================================================================
        // TC9: Direction timeout
        // Keep a tag stuck long enough to trigger timeout.
        // =====================================================================
        scenario_id = 9;
        $display("\n=== TC9 DIRECTION TIMEOUT ===");
        sim_uid_s = UID_NORMAL;
        sim_tag_detected = 4'b0100;
        repeat (28) @(posedge clk);
        begin : WAIT_DIR_VALID_3
            integer n;
            reg seen_valid;
            seen_valid = 1'b0;
            for (n = 0; n < 10; n = n + 1) begin
                @(posedge clk);
                #1;
                if (dir_valid) begin
                    seen_valid = 1'b1;
                    check(dir_confidence == 1'b0,
                          "Direction timeout is marked LOW confidence");
                    disable WAIT_DIR_VALID_3;
                end
            end
            if (!seen_valid)
                check(1'b0, "Direction timeout produced dir_valid pulse");
        end
        clear_inputs();

        repeat (5) @(posedge clk);

        $display("\n============================================================");
        $display("FUNCTIONAL VERIFICATION SUMMARY");
        $display("PASS = %0d", pass_count);
        $display("FAIL = %0d", fail_count);
        if (fail_count == 0)
            $display("OVERALL RESULT: PASS");
        else
            $display("OVERALL RESULT: FAIL");
        $display("============================================================\n");

        $finish;
    end

endmodule
