`timescale 1ns/1ps
module tb_cascade_packet_loopback;
    localparam CLK_PERIOD=20;
    localparam CLKS_PER_BIT=12;

    reg clk=0, rst_n=0;
    reg send, valid, direction, clear;
    reg [4:0] src_node_id;
    reg [2:0] prio_class;
    reg [7:0] eta;

    wire [7:0] tx_byte;
    wire tx_byte_start;
    wire packet_tx_done;
    wire serial, uart_busy, uart_done;
    wire [7:0] rx_byte;
    wire rx_byte_valid, rx_error;
    wire pkt_valid, pkt_flag_valid, pkt_flag_dir, pkt_flag_clear, pkt_error;
    wire [4:0] pkt_src_id;
    wire [2:0] pkt_class;
    wire [7:0] pkt_eta;

    integer pass_count=0, fail_count=0, k;

    cascade_tx u_ctx(
        .clk(clk),.rst_n(rst_n),.send(send),.valid(valid),.direction(direction),
        .clear(clear),.src_node_id(src_node_id),.prio_class(prio_class),.eta(eta),
        .uart_tx_busy(uart_busy),.uart_tx_data(tx_byte),
        .uart_tx_start(tx_byte_start),.tx_done(packet_tx_done)
    );

    uart_tx_core #(.BAUD_DIV(CLKS_PER_BIT)) u_utx(
        .clk(clk),.rst_n(rst_n),.tx_data(tx_byte),.tx_start(tx_byte_start),
        .tx_serial(serial),.tx_busy(uart_busy),.tx_done(uart_done)
    );

    uart_rx_core #(.CLKS_PER_BIT(CLKS_PER_BIT),.HALF_BIT(CLKS_PER_BIT/2)) u_urx(
        .clk(clk),.rst_n(rst_n),.rx_serial(serial),
        .rx_data(rx_byte),.rx_valid(rx_byte_valid),.rx_error(rx_error)
    );

    cascade_rx #(.PKT_TIMEOUT(20'd200)) u_crx(
        .clk(clk),.rst_n(rst_n),.uart_rx_data(rx_byte),.uart_rx_valid(rx_byte_valid),
        .pkt_valid(pkt_valid),.pkt_flag_valid(pkt_flag_valid),
        .pkt_flag_dir(pkt_flag_dir),.pkt_flag_clear(pkt_flag_clear),
        .pkt_src_id(pkt_src_id),.pkt_class(pkt_class),.pkt_eta(pkt_eta),
        .pkt_error(pkt_error)
    );

    always #(CLK_PERIOD/2) clk=~clk;

    task check;
        input cond; input [8*110-1:0] msg;
        begin
            if(cond) begin pass_count=pass_count+1; $display("[PASS] %0s",msg); end
            else begin fail_count=fail_count+1; $display("[FAIL] %0s",msg); end
        end
    endtask

    task send_packet_and_check;
        input iv, idir, iclr;
        input [4:0] isrc;
        input [2:0] iclass;
        input [7:0] ieta;
        reg seen;
        begin
            valid=iv; direction=idir; clear=iclr; src_node_id=isrc;
            prio_class=iclass; eta=ieta; send=1;
            @(posedge clk); send=0;
            seen=0;
            begin : WAIT_PACKET
                for(k=0;k<CLKS_PER_BIT*80;k=k+1) begin
                    @(posedge clk); #1;
                    if(pkt_valid) begin
                        seen=1;
                        check(pkt_flag_valid==iv,"Packet valid flag parsed");
                        check(pkt_flag_dir==idir,"Packet direction parsed");
                        check(pkt_flag_clear==iclr,"Packet clear flag parsed");
                        check(pkt_src_id==isrc,"Packet source ID parsed");
                        check(pkt_class==iclass,"Packet priority class parsed");
                        check(pkt_eta==ieta,"Packet ETA parsed");
                        check(!pkt_error,"No packet error");
                        disable WAIT_PACKET;
                    end
                end
            end
            check(seen,"Complete 5-byte packet received");
            repeat(4) @(posedge clk);
        end
    endtask

    task drive_rx_byte;
        input [7:0] b;
        begin
            force u_crx.uart_rx_data=b;
            force u_crx.uart_rx_valid=1'b1;
            @(posedge clk);
            release u_crx.uart_rx_data;
            release u_crx.uart_rx_valid;
            @(posedge clk);
        end
    endtask

    initial begin
        send=0; valid=0; direction=0; clear=0; src_node_id=0; prio_class=0; eta=0;
        repeat(4) @(posedge clk); rst_n=1; repeat(3) @(posedge clk);

        send_packet_and_check(1,1,0,5'd2,3'd5,8'd9);
        send_packet_and_check(1,0,1,5'd1,3'd0,8'd0);

        // Bad checksum injected directly at cascade_rx byte interface.
        drive_rx_byte(8'hCA);
        drive_rx_byte(8'hC1);
        drive_rx_byte(8'h05);
        drive_rx_byte(8'h07);
        drive_rx_byte(8'h00); // deliberately wrong
        repeat(3) @(posedge clk);
        check(pkt_error,"Bad checksum raises pkt_error");

        $display("CASCADE PACKET SUMMARY PASS=%0d FAIL=%0d",pass_count,fail_count);
        if(fail_count==0) $display("OVERALL RESULT: PASS");
        else $display("OVERALL RESULT: FAIL");
        $finish;
    end
endmodule
