`timescale 1ns/1ps
`define SIMULATION
module tb_seg7_countdown;
    reg clk=0,rst_n=0;
    reg [3:0] cur_state;
    wire dio,sclk,rclk;
    integer pass_count=0,fail_count=0,k,rclk_pulses;
    reg rclk_d;

    seg7_countdown dut(
        .clk(clk),.rst_n(rst_n),.cur_state(cur_state),
        .seg7_dio(dio),.seg7_sclk(sclk),.seg7_rclk(rclk)
    );

    always #10 clk=~clk;
    always @(posedge clk) begin
        rclk_d<=rclk;
        if(!rclk_d && rclk) rclk_pulses<=rclk_pulses+1;
    end
    task check; input cond; input [8*100-1:0] msg;
      begin if(cond) begin pass_count=pass_count+1;$display("[PASS] %0s",msg);end
      else begin fail_count=fail_count+1;$display("[FAIL] %0s",msg);end end
    endtask

    initial begin
        cur_state=0;rclk_pulses=0;rclk_d=0;
        repeat(4)@(posedge clk);rst_n=1;
        repeat(3000)@(posedge clk);
        check(rclk_pulses>0,"7-segment driver generates latch pulses");
        check(dut.ns_seconds==7'd3 && dut.ew_seconds==7'd3,
              "NS_GREEN loads simulation countdown");
        cur_state=4'd3;
        repeat(4)@(posedge clk);
        check(dut.ns_seconds==7'd2 && dut.ew_seconds==7'd2,
              "EW_GREEN reloads countdown values");
        cur_state=4'd7;
        repeat(4)@(posedge clk);
        check(dut.ns_seconds==7'd5 && dut.ew_seconds==7'd5,
              "Priority hold loads priority countdown");
        $display("SEG7 SUMMARY PASS=%0d FAIL=%0d",pass_count,fail_count);
        if(fail_count==0)$display("OVERALL RESULT: PASS"); else $display("OVERALL RESULT: FAIL");
        $finish;
    end
endmodule
