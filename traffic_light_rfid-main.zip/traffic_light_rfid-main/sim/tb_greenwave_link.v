`timescale 1ns/1ps
module tb_greenwave_link;
    localparam CLKS_PER_BIT=12;
    reg clk=0,rst_n=0;

    // Source local event
    reg src_prio_active;
    reg [2:0] src_winner_class;
    reg [1:0] src_dir_out;
    reg src_dir_valid;

    // Source controller to TX
    wire s_r_send,s_r_valid,s_r_dir,s_r_clear;
    wire [2:0] s_r_class;
    wire [7:0] s_r_eta;

    // UART chain
    wire [7:0] ctx_data;
    wire ctx_start,ctx_done;
    wire serial,utx_busy,utx_done;
    wire [7:0] urx_data;
    wire urx_valid,urx_error;

    // Destination parsed packet
    wire d_pkt_valid,d_flag_valid,d_flag_dir,d_flag_clear,d_pkt_error;
    wire [4:0] d_src_id;
    wire [2:0] d_class;
    wire [7:0] d_eta;

    // Destination controller
    wire d_preclear;
    wire d_l_send,d_l_valid,d_l_dir,d_l_clear;
    wire [2:0] d_l_class;
    wire [7:0] d_l_eta;

    integer pass_count=0,fail_count=0,k;

    cascade_ctrl #(.INTER_NODE_DELAY(8'd5)) src_ctrl(
        .clk(clk),.rst_n(rst_n),.node_id(2'd0),
        .prio_active(src_prio_active),.winner_class(src_winner_class),
        .dir_out(src_dir_out),.dir_valid(src_dir_valid),.dir_confidence(1'b1),
        .left_pkt_valid(1'b0),.left_pkt_flag_dir(1'b0),.left_pkt_flag_clear(1'b0),.left_pkt_class(3'd0),.left_pkt_eta(8'd0),
        .right_pkt_valid(1'b0),.right_pkt_flag_dir(1'b0),.right_pkt_flag_clear(1'b0),.right_pkt_class(3'd0),.right_pkt_eta(8'd0),
        .left_tx_send(),.left_tx_valid(),.left_tx_dir(),.left_tx_clear(),.left_tx_class(),.left_tx_eta(),
        .right_tx_send(s_r_send),.right_tx_valid(s_r_valid),.right_tx_dir(s_r_dir),
        .right_tx_clear(s_r_clear),.right_tx_class(s_r_class),.right_tx_eta(s_r_eta),
        .preclear_req()
    );

    cascade_tx ctx(
        .clk(clk),.rst_n(rst_n),.send(s_r_send),.valid(s_r_valid),.direction(s_r_dir),
        .clear(s_r_clear),.src_node_id(5'd0),.prio_class(s_r_class),.eta(s_r_eta),
        .uart_tx_busy(utx_busy),.uart_tx_data(ctx_data),.uart_tx_start(ctx_start),.tx_done(ctx_done)
    );
    uart_tx_core #(.BAUD_DIV(CLKS_PER_BIT)) utx(
        .clk(clk),.rst_n(rst_n),.tx_data(ctx_data),.tx_start(ctx_start),
        .tx_serial(serial),.tx_busy(utx_busy),.tx_done(utx_done)
    );
    uart_rx_core #(.CLKS_PER_BIT(CLKS_PER_BIT),.HALF_BIT(CLKS_PER_BIT/2)) urx(
        .clk(clk),.rst_n(rst_n),.rx_serial(serial),
        .rx_data(urx_data),.rx_valid(urx_valid),.rx_error(urx_error)
    );
    cascade_rx #(.PKT_TIMEOUT(20'd200)) crx(
        .clk(clk),.rst_n(rst_n),.uart_rx_data(urx_data),.uart_rx_valid(urx_valid),
        .pkt_valid(d_pkt_valid),.pkt_flag_valid(d_flag_valid),.pkt_flag_dir(d_flag_dir),
        .pkt_flag_clear(d_flag_clear),.pkt_src_id(d_src_id),.pkt_class(d_class),
        .pkt_eta(d_eta),.pkt_error(d_pkt_error)
    );

    cascade_ctrl #(.INTER_NODE_DELAY(8'd5)) dst_ctrl(
        .clk(clk),.rst_n(rst_n),.node_id(2'd1),
        .prio_active(1'b0),.winner_class(3'd0),.dir_out(2'd0),.dir_valid(1'b0),.dir_confidence(1'b0),
        .left_pkt_valid(d_pkt_valid),.left_pkt_flag_dir(d_flag_dir),
        .left_pkt_flag_clear(d_flag_clear),.left_pkt_class(d_class),.left_pkt_eta(d_eta),
        .right_pkt_valid(1'b0),.right_pkt_flag_dir(1'b0),.right_pkt_flag_clear(1'b0),.right_pkt_class(3'd0),.right_pkt_eta(8'd0),
        .left_tx_send(),.left_tx_valid(),.left_tx_dir(),.left_tx_clear(),.left_tx_class(),.left_tx_eta(),
        .right_tx_send(d_l_send),.right_tx_valid(d_l_valid),.right_tx_dir(d_l_dir),
        .right_tx_clear(d_l_clear),.right_tx_class(d_l_class),.right_tx_eta(d_l_eta),
        .preclear_req(d_preclear)
    );

    always #10 clk=~clk;
    task check; input cond; input [8*120-1:0] msg;
      begin if(cond) begin pass_count=pass_count+1;$display("[PASS] %0s",msg);end
      else begin fail_count=fail_count+1;$display("[FAIL] %0s",msg);end end
    endtask

    initial begin
        src_prio_active=0;src_winner_class=0;src_dir_out=0;src_dir_valid=0;
        repeat(4) @(posedge clk);rst_n=1;repeat(3) @(posedge clk);

        // Vehicle at node 0 heading EAST.
        src_prio_active=1;src_winner_class=3'd5;src_dir_out=2'b10;src_dir_valid=1;
        @(posedge clk);src_dir_valid=0;

        begin : WAIT_DEST
            reg seen;
            seen=0;
            for(k=0;k<CLKS_PER_BIT*90;k=k+1) begin
                @(posedge clk); #1;
                if(d_preclear) begin
                    seen=1;
                    check(d_pkt_valid,"Destination received valid cascade packet");
                    check(d_class==3'd5 && d_flag_dir==1'b1 && d_eta==8'd5,
                          "Destination packet fields preserve class/direction/ETA");
                    check(d_l_send && d_l_eta==8'd10,
                          "Destination forwards packet with incremented ETA");
                    disable WAIT_DEST;
                end
            end
            check(seen,"End-to-end Green Wave preclear reached destination node");
        end

        $display("GREEN WAVE LINK SUMMARY PASS=%0d FAIL=%0d",pass_count,fail_count);
        if(fail_count==0)$display("OVERALL RESULT: PASS"); else $display("OVERALL RESULT: FAIL");
        $finish;
    end
endmodule
