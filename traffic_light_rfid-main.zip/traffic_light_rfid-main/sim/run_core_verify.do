transcript on
if {[file exists work]} {
    vdel -lib work -all
}
vlib work
vmap work work

# Compile only the core scope used in the paper.
vlog +define+SIMULATION \
    phase_timer.v \
    tag_priority_lut.v \
    priority_arbiter.v \
    direction_detector.v \
    traffic_fsm.v \
    tb_core_verification.v

vsim -voptargs=+acc work.tb_core_verification

# Wave groups for publication-quality capture
add wave -divider "Test Control"
add wave -radix unsigned sim:/tb_core_verification/scenario_id
add wave sim:/tb_core_verification/clk
add wave sim:/tb_core_verification/rst_n

add wave -divider "RFID Stimulus"
add wave -radix binary sim:/tb_core_verification/sim_tag_detected
add wave -radix hexadecimal sim:/tb_core_verification/sim_uid_n
add wave -radix hexadecimal sim:/tb_core_verification/sim_uid_s
add wave -radix hexadecimal sim:/tb_core_verification/sim_uid_e
add wave -radix hexadecimal sim:/tb_core_verification/sim_uid_w

add wave -divider "Priority Resolution"
add wave -radix unsigned sim:/tb_core_verification/class_n
add wave -radix unsigned sim:/tb_core_verification/class_s
add wave -radix unsigned sim:/tb_core_verification/class_e
add wave -radix unsigned sim:/tb_core_verification/class_w
add wave sim:/tb_core_verification/arb_ev_ns
add wave sim:/tb_core_verification/arb_ev_ew
add wave -radix unsigned sim:/tb_core_verification/arb_winner

add wave -divider "Direction Inference"
add wave -radix binary sim:/tb_core_verification/u_dir/falling
add wave -radix binary sim:/tb_core_verification/u_dir/seen_mask
add wave -radix unsigned sim:/tb_core_verification/u_dir/state
add wave -radix unsigned sim:/tb_core_verification/dir_out
add wave sim:/tb_core_verification/dir_valid
add wave sim:/tb_core_verification/dir_confidence

add wave -divider "Traffic FSM"
add wave -radix unsigned sim:/tb_core_verification/cur_state
add wave -radix unsigned sim:/tb_core_verification/u_fsm/next_state
add wave sim:/tb_core_verification/u_fsm/timer_expired
add wave sim:/tb_core_verification/timer_load
add wave -radix unsigned sim:/tb_core_verification/timer_value
add wave sim:/tb_core_verification/prio_active

add wave -divider "Traffic Lights"
add wave sim:/tb_core_verification/ns_r
add wave sim:/tb_core_verification/ns_y
add wave sim:/tb_core_verification/ns_g
add wave sim:/tb_core_verification/ew_r
add wave sim:/tb_core_verification/ew_y
add wave sim:/tb_core_verification/ew_g

run -all
wave zoom full
