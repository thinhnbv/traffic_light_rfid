`timescale 1ns/1ps
module tb_rc522_smoke;
    reg clk=0,rst_n=0,spi_miso=0;
    wire spi_sck,spi_mosi;
    wire [3:0] cs_n,tag_detected;
    wire [31:0] uid_n,uid_s,uid_e,uid_w;
    integer pass_count=0,fail_count=0,k;
    reg saw_spi,saw_reader0,saw_reader1,saw_reader2,saw_reader3;

    rc522_driver_x4 #(
        .SPI_CLK_DIV(3'd1),
        .REQA_TIMEOUT(16'd20),
        .CS_DESELECT_WAIT(16'd3),
        .POR_WAIT(24'd5)
    ) dut(
        .clk(clk),.rst_n(rst_n),.spi_miso(spi_miso),.spi_sck(spi_sck),.spi_mosi(spi_mosi),
        .cs_n(cs_n),.tag_detected(tag_detected),
        .tag_uid_n(uid_n),.tag_uid_s(uid_s),.tag_uid_e(uid_e),.tag_uid_w(uid_w)
    );

    always #10 clk=~clk;
    task check; input cond; input [8*110-1:0] msg;
      begin if(cond) begin pass_count=pass_count+1;$display("[PASS] %0s",msg);end
      else begin fail_count=fail_count+1;$display("[FAIL] %0s",msg);end end
    endtask

    always @(posedge clk) begin
        if(spi_sck) saw_spi<=1;
        case(cs_n)
            4'b1110:saw_reader0<=1;
            4'b1101:saw_reader1<=1;
            4'b1011:saw_reader2<=1;
            4'b0111:saw_reader3<=1;
        endcase
        if(rst_n) begin
            if(!(cs_n==4'b1111 || cs_n==4'b1110 || cs_n==4'b1101 || cs_n==4'b1011 || cs_n==4'b0111)) begin
                fail_count=fail_count+1;
                $display("[FAIL] RC522 CS is not one-hot active-low: %b",cs_n);
            end
        end
    end

    initial begin
        saw_spi=0;saw_reader0=0;saw_reader1=0;saw_reader2=0;saw_reader3=0;
        repeat(4)@(posedge clk);rst_n=1;
        // Enough cycles for init across four readers with shortened parameters.
        repeat(12000) @(posedge clk);
        check(saw_spi,"RC522 driver generated SPI activity");
        check(saw_reader0&&saw_reader1&&saw_reader2&&saw_reader3,
              "RC522 driver selected all four readers");
        check(tag_detected==4'b0000,"No-tag MISO model leaves tag_detected clear");
        $display("RC522 SMOKE SUMMARY PASS=%0d FAIL=%0d",pass_count,fail_count);
        if(fail_count==0)$display("OVERALL RESULT: PASS"); else $display("OVERALL RESULT: FAIL");
        $finish;
    end
endmodule
