`timescale 1ns/1ps
module tb_cascade_ctrl;
    reg clk=0,rst_n=0;
    reg [1:0] node_id=2'd1;
    reg prio_active;
    reg [2:0] winner_class;
    reg [1:0] dir_out;
    reg dir_valid,dir_confidence;
    reg left_pkt_valid,left_pkt_flag_dir,left_pkt_flag_clear;
    reg [2:0] left_pkt_class;
    reg [7:0] left_pkt_eta;
    reg right_pkt_valid,right_pkt_flag_dir,right_pkt_flag_clear;
    reg [2:0] right_pkt_class;
    reg [7:0] right_pkt_eta;

    wire left_tx_send,left_tx_valid,left_tx_dir,left_tx_clear;
    wire [2:0] left_tx_class;
    wire [7:0] left_tx_eta;
    wire right_tx_send,right_tx_valid,right_tx_dir,right_tx_clear;
    wire [2:0] right_tx_class;
    wire [7:0] right_tx_eta;
    wire preclear_req;

    integer pass_count=0,fail_count=0;

    cascade_ctrl #(.INTER_NODE_DELAY(8'd5)) dut(
        .clk(clk),.rst_n(rst_n),.node_id(node_id),
        .prio_active(prio_active),.winner_class(winner_class),
        .dir_out(dir_out),.dir_valid(dir_valid),.dir_confidence(dir_confidence),
        .left_pkt_valid(left_pkt_valid),.left_pkt_flag_dir(left_pkt_flag_dir),
        .left_pkt_flag_clear(left_pkt_flag_clear),.left_pkt_class(left_pkt_class),.left_pkt_eta(left_pkt_eta),
        .right_pkt_valid(right_pkt_valid),.right_pkt_flag_dir(right_pkt_flag_dir),
        .right_pkt_flag_clear(right_pkt_flag_clear),.right_pkt_class(right_pkt_class),.right_pkt_eta(right_pkt_eta),
        .left_tx_send(left_tx_send),.left_tx_valid(left_tx_valid),.left_tx_dir(left_tx_dir),
        .left_tx_clear(left_tx_clear),.left_tx_class(left_tx_class),.left_tx_eta(left_tx_eta),
        .right_tx_send(right_tx_send),.right_tx_valid(right_tx_valid),.right_tx_dir(right_tx_dir),
        .right_tx_clear(right_tx_clear),.right_tx_class(right_tx_class),.right_tx_eta(right_tx_eta),
        .preclear_req(preclear_req)
    );

    always #10 clk=~clk;

    task check; input cond; input [8*100-1:0] msg;
        begin if(cond) begin pass_count=pass_count+1;$display("[PASS] %0s",msg);end
        else begin fail_count=fail_count+1;$display("[FAIL] %0s",msg);end end
    endtask
    task clear_inputs;
        begin
            prio_active=0;winner_class=0;dir_out=0;dir_valid=0;dir_confidence=0;
            left_pkt_valid=0;left_pkt_flag_dir=0;left_pkt_flag_clear=0;left_pkt_class=0;left_pkt_eta=0;
            right_pkt_valid=0;right_pkt_flag_dir=0;right_pkt_flag_clear=0;right_pkt_class=0;right_pkt_eta=0;
        end
    endtask

    initial begin
        clear_inputs(); repeat(3) @(posedge clk); rst_n=1; repeat(2) @(posedge clk);

        // Local EAST event -> right neighbor only.
        prio_active=1;winner_class=5;dir_out=2'b10;dir_confidence=1;dir_valid=1;
        @(posedge clk); #1;
        check(right_tx_send && !left_tx_send,"Local EAST event routes RIGHT only");
        check(right_tx_dir && right_tx_class==5 && right_tx_eta==5,"RIGHT packet fields correct");
        dir_valid=0; @(posedge clk);

        // Local WEST event -> left only.
        dir_out=2'b11;dir_valid=1; @(posedge clk); #1;
        check(left_tx_send && !right_tx_send,"Local WEST event routes LEFT only");
        dir_valid=0; @(posedge clk);

        // Local NORTH event -> broadcast.
        dir_out=2'b00;dir_valid=1; @(posedge clk); #1;
        check(left_tx_send && right_tx_send,"Local NS event broadcasts both neighbors");
        dir_valid=0; @(posedge clk);

        // Falling prio_active -> clear packet both directions.
        prio_active=0; @(posedge clk); #1;
        check(left_tx_send && right_tx_send && left_tx_clear && right_tx_clear,
              "Priority falling edge broadcasts clear packet");
        @(posedge clk);

        // Packet from LEFT -> preclear and forward RIGHT with ETA+5.
        left_pkt_valid=1;left_pkt_flag_dir=1;left_pkt_flag_clear=0;left_pkt_class=4;left_pkt_eta=8'd250;
        @(posedge clk); #1;
        check(preclear_req,"LEFT remote event asserts preclear");
        check(right_tx_send && right_tx_eta==8'd255,"ETA saturates at 255 when forwarding RIGHT");
        left_pkt_valid=0; @(posedge clk);

        // Clear packet should not preclear.
        right_pkt_valid=1;right_pkt_flag_clear=1;right_pkt_eta=0;
        @(posedge clk); #1;
        check(!preclear_req,"Remote clear packet does not assert preclear");
        right_pkt_valid=0;

        $display("CASCADE CTRL SUMMARY PASS=%0d FAIL=%0d",pass_count,fail_count);
        if(fail_count==0)$display("OVERALL RESULT: PASS"); else $display("OVERALL RESULT: FAIL");
        $finish;
    end
endmodule
