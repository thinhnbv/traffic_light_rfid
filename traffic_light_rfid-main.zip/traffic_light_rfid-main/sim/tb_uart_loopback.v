`timescale 1ns/1ps
module tb_uart_loopback;
    localparam CLK_PERIOD = 20;
    localparam CLKS_PER_BIT = 16;

    reg clk=0, rst_n=0;
    reg [7:0] tx_data;
    reg tx_start;
    wire tx_serial, tx_busy, tx_done;
    wire [7:0] rx_data;
    wire rx_valid, rx_error;

    integer pass_count=0, fail_count=0;

    uart_tx_core #(.BAUD_DIV(CLKS_PER_BIT)) u_tx (
        .clk(clk), .rst_n(rst_n), .tx_data(tx_data), .tx_start(tx_start),
        .tx_serial(tx_serial), .tx_busy(tx_busy), .tx_done(tx_done)
    );

    uart_rx_core #(.CLKS_PER_BIT(CLKS_PER_BIT), .HALF_BIT(CLKS_PER_BIT/2)) u_rx (
        .clk(clk), .rst_n(rst_n), .rx_serial(tx_serial),
        .rx_data(rx_data), .rx_valid(rx_valid), .rx_error(rx_error)
    );

    always #(CLK_PERIOD/2) clk = ~clk;

    task check;
        input cond;
        input [8*100-1:0] msg;
        begin
            if (cond) begin pass_count=pass_count+1; $display("[PASS] %0s",msg); end
            else begin fail_count=fail_count+1; $display("[FAIL] %0s",msg); end
        end
    endtask

    task send_byte;
        input [7:0] b;
        integer k;
        reg seen;
        begin
            while (tx_busy) @(posedge clk);
            tx_data=b; tx_start=1;
            @(posedge clk); tx_start=0;
            seen=0;
            begin : WAIT_RX
                for(k=0;k<CLKS_PER_BIT*14;k=k+1) begin
                    @(posedge clk); #1;
                    if(rx_valid) begin
                        seen=1;
                        check(rx_data==b,"UART loopback data matches");
                        check(!rx_error,"No UART framing error");
                        disable WAIT_RX;
                    end
                end
            end
            check(seen,"UART rx_valid observed");
        end
    endtask

    initial begin
        tx_data=0; tx_start=0;
        repeat(4) @(posedge clk); rst_n=1; repeat(3) @(posedge clk);

        send_byte(8'h55);
        send_byte(8'hA3);
        send_byte(8'h00);
        send_byte(8'hFF);

        // False start pulse shorter than HALF_BIT.
        force u_rx.rx_serial = 1'b0;
        repeat(2) @(posedge clk);
        release u_rx.rx_serial;
        repeat(CLKS_PER_BIT*2) @(posedge clk);
        check(!rx_valid,"False start does not create valid byte");

        $display("UART SUMMARY PASS=%0d FAIL=%0d",pass_count,fail_count);
        if(fail_count==0) $display("OVERALL RESULT: PASS");
        else $display("OVERALL RESULT: FAIL");
        $finish;
    end
endmodule
