transcript on

# Resolve paths relative to this .do file.
set SCRIPT_DIR [file normalize [file dirname [info script]]]
set SRC_DIR    [file normalize [file join $SCRIPT_DIR .. src]]
set TB_FILE    [file normalize [file join $SCRIPT_DIR tb_core_verification.v]]
set WORK_DIR   [file normalize [file join $SCRIPT_DIR work_verify]]

puts "SCRIPT_DIR = $SCRIPT_DIR"
puts "SRC_DIR    = $SRC_DIR"
puts "WORK_DIR   = $WORK_DIR"

# Use a dedicated verification library so ModelSim does not need to delete
# the project's currently open/locked 'work' library.
if {![file exists $WORK_DIR]} {
    vlib $WORK_DIR
}
vmap work $WORK_DIR

# Check that every required file exists before compilation.
set RTL_FILES [list \
    [file join $SRC_DIR phase_timer.v] \
    [file join $SRC_DIR tag_priority_lut.v] \
    [file join $SRC_DIR priority_arbiter.v] \
    [file join $SRC_DIR direction_detector.v] \
    [file join $SRC_DIR traffic_fsm.v] \
]

foreach f $RTL_FILES {
    if {![file exists $f]} {
        puts "ERROR: Missing RTL file: $f"
        puts "Edit SRC_DIR in run_core_verify_fixed.do if your RTL files are elsewhere."
        return
    }
}

if {![file exists $TB_FILE]} {
    puts "ERROR: Missing testbench: $TB_FILE"
    return
}

eval vlog +define+SIMULATION $RTL_FILES $TB_FILE

vsim -voptargs=+acc work.tb_core_verification

add wave -divider "Test Control"
add wave -radix unsigned sim:/tb_core_verification/scenario_id
add wave sim:/tb_core_verification/clk
add wave sim:/tb_core_verification/rst_n

add wave -divider "RFID Stimulus"
add wave -radix binary sim:/tb_core_verification/sim_tag_detected
add wave -radix hexadecimal sim:/tb_core_verification/sim_uid_n
add wave -radix hexadecimal sim:/tb_core_verification/sim_uid_s
add wave -radix hexadecimal sim:/tb_core_verification/sim_uid_e
add wave -radix hexadecimal sim:/tb_core_verification/sim_uid_w

add wave -divider "Priority Resolution"
add wave -radix unsigned sim:/tb_core_verification/class_n
add wave -radix unsigned sim:/tb_core_verification/class_s
add wave -radix unsigned sim:/tb_core_verification/class_e
add wave -radix unsigned sim:/tb_core_verification/class_w
add wave sim:/tb_core_verification/arb_ev_ns
add wave sim:/tb_core_verification/arb_ev_ew
add wave -radix unsigned sim:/tb_core_verification/arb_winner

add wave -divider "Direction Inference"
add wave -radix binary sim:/tb_core_verification/u_dir/falling
add wave -radix binary sim:/tb_core_verification/u_dir/seen_mask
add wave -radix unsigned sim:/tb_core_verification/u_dir/state
add wave -radix unsigned sim:/tb_core_verification/dir_out
add wave sim:/tb_core_verification/dir_valid
add wave sim:/tb_core_verification/dir_confidence

add wave -divider "Traffic FSM"
add wave -radix unsigned sim:/tb_core_verification/cur_state
add wave -radix unsigned sim:/tb_core_verification/u_fsm/next_state
add wave sim:/tb_core_verification/u_fsm/timer_expired
add wave sim:/tb_core_verification/timer_load
add wave -radix unsigned sim:/tb_core_verification/timer_value
add wave sim:/tb_core_verification/prio_active

add wave -divider "Traffic Lights"
add wave sim:/tb_core_verification/ns_r
add wave sim:/tb_core_verification/ns_y
add wave sim:/tb_core_verification/ns_g
add wave sim:/tb_core_verification/ew_r
add wave sim:/tb_core_verification/ew_y
add wave sim:/tb_core_verification/ew_g

run -all
wave zoom full
